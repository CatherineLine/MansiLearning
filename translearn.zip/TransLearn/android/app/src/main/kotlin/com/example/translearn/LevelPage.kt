package com.example.translearn

import io.flutter.embedding.android.FlutterActivity

class LevelPage: FlutterActivity()
